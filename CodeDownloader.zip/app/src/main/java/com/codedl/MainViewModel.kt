package com.codedl

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.codedl.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed interface UiState {
    data object Idle : UiState
    data object Resolving : UiState
    data class Downloading(val name: String, val progress: Float?, val speed: Double) : UiState
    data class Error(val message: String) : UiState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val client = OkHttpClient.Builder().readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { c ->
            c.proceed(c.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 11; AFTV) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                .build())
        }.build()
    private val resolver = UrlResolver(client)
    private val downloader = Downloader(client, app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!)
    private val store = HistoryStore(app)

    private val _code = MutableStateFlow("")
    val code = _code.asStateFlow()
    private val _ui = MutableStateFlow<UiState>(UiState.Idle)
    val ui = _ui.asStateFlow()
    private val _history = MutableStateFlow(store.load())
    val history = _history.asStateFlow()

    private var job: Job? = null
    private var pendingApk: File? = null

    fun append(c: Char) { if (_code.value.length < 12) _code.value += c; clearError() }
    fun backspace() { _code.value = _code.value.dropLast(1); clearError() }
    fun clear() { _code.value = ""; clearError() }
    private fun clearError() { if (_ui.value is UiState.Error) _ui.value = UiState.Idle }

    fun start(codeToUse: String = _code.value) {
        val c = codeToUse.trim()
        if (c.isEmpty() || job?.isActive == true) return
        job = viewModelScope.launch {
            _ui.value = UiState.Resolving
            val url = resolver.resolve(c).getOrElse {
                _ui.value = UiState.Error(
                    if (it is IOException) "Sem conexão. Verifique a internet."
                    else "Código não encontrado ou link expirado."
                )
                return@launch
            }
            try {
                val file = downloader.download(url, "download_$c") { name, done, total, speed ->
                    _ui.value = UiState.Downloading(name, if (total > 0) done.toFloat() / total else null, speed)
                }
                _history.value = store.add(HistoryItem(c, file.name, file.absolutePath, System.currentTimeMillis()))
                _ui.value = UiState.Idle
                _code.value = ""
                if (file.extension.equals("apk", true)) {
                    if (!Installer.install(getApplication(), file)) pendingApk = file
                }
            } catch (e: Exception) {
                ensureActive()
                _ui.value = UiState.Error("Falha no download. Tente novamente.")
            }
        }
    }

    fun cancel() { job?.cancel(); _ui.value = UiState.Idle }

    fun delete(item: HistoryItem) {
        File(item.path).delete()
        _history.value = store.remove(item)
    }

    /** onResume: continua a instalação após o usuário liberar "fontes desconhecidas". */
    fun resumePendingInstall() {
        pendingApk?.let { if (Installer.install(getApplication(), it)) pendingApk = null }
    }
}
