package com.codedl.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class NotFoundException : Exception()

/**
 * O aftv.news NÃO responde só com redirect HTTP: ele mostra uma página intermediária (HTML)
 * e só depois manda para a URL final. Por isso o resolver segue 3xx E também extrai o destino
 * do HTML (meta refresh, location.href/replace, ou o primeiro link externo).
 */
class UrlResolver(base: OkHttpClient) {
    private val client = base.newBuilder().followRedirects(false).followSslRedirects(false).build()

    suspend fun resolve(code: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            var url = "https://aftv.news/${code.trim()}"
            var hops = 0
            while (hops++ < 10) {
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    val type = resp.header("Content-Type").orEmpty().lowercase()
                    when {
                        resp.code in listOf(301, 302, 303, 307, 308) -> {
                            val loc = resp.header("Location") ?: throw NotFoundException()
                            url = resp.request.url.resolve(loc)?.toString() ?: throw NotFoundException()
                        }
                        resp.isSuccessful && type.startsWith("text/html") -> {
                            val html = resp.body?.source()?.let { it.request(300_000); it.buffer.clone().readUtf8() }.orEmpty()
                            val target = extractTarget(html) ?: throw NotFoundException()
                            url = resp.request.url.resolve(target)?.toString() ?: throw NotFoundException()
                        }
                        resp.isSuccessful -> return@withContext Result.success(url)
                        else -> throw NotFoundException()
                    }
                }
            }
            Result.failure(NotFoundException())
        } catch (e: IOException) {
            Result.failure(e)
        } catch (e: NotFoundException) {
            Result.failure(e)
        }
    }

    private fun clean(s: String) = s.replace("\\/", "/").replace("&amp;", "&").trim()

    private fun extractTarget(html: String): String? {
        val patterns = listOf(
            Regex("""<meta[^>]+http-equiv=["']?refresh["']?[^>]*content=["'][^"']*?url=\s*([^"'>\s]+)""", RegexOption.IGNORE_CASE),
            Regex("""location\.(?:replace|assign)\(\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""location(?:\.href)?\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE),
        )
        for (p in patterns) p.find(html)?.groupValues?.get(1)?.let { return clean(it) }
        // fallback: primeiro link absoluto que não seja do próprio AFTVnews
        return Regex("""href=["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
            .findAll(html).map { clean(it.groupValues[1]) }
            .firstOrNull { !it.contains("aftv", ignoreCase = true) }
    }
}
