package com.codedl.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object C {
    val Bg = Color(0xFF121212)
    val Card = Color(0xFF1E1E1E)
    val Key = Color(0xFF2A2A2A)
    val Text = Color(0xFFE0E0E0)
    val Muted = Color(0xFF9E9E9E)
    val Accent = Color(0xFF2979FF)
    val Neon = Color(0xFF00E676)
    val Error = Color(0xFFFF5252)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = C.Accent, background = C.Bg, surface = C.Card,
        onBackground = C.Text, onSurface = C.Text, error = C.Error
    ),
    content = content
)

/** Botão com estado de foco visível (D-Pad) e suporte a toque. */
@Composable
fun FocusButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    container: Color = C.Key,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "focusScale")
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .scale(scale)
            .clip(shape)
            .background(container)
            .border(if (focused) 3.dp else 0.dp, if (focused) C.Neon else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}
