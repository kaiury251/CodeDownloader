package com.codedl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.codedl.MainViewModel
import com.codedl.UiState
import com.codedl.data.HistoryItem

@Composable
fun MainScreen(vm: MainViewModel) {
    val code by vm.code.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val firstKey = remember { FocusRequester() }
    LaunchedEffect(Unit) { firstKey.requestFocus() }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(C.Bg)
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                if (e.key == Key.Backspace || e.key == Key.Delete) { vm.backspace(); return@onPreviewKeyEvent true }
                val ch = e.utf16CodePoint.toChar()
                if (ch.isLetterOrDigit()) { vm.append(ch); true } else false
            }
    ) {
        val wide = maxWidth >= 840.dp
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp)) {
            Header()
            Spacer(Modifier.height(16.dp))
            if (wide) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        CodePanel(vm, code, ui, firstKey)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        HistoryPanel(history, vm)
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    CodePanel(vm, code, ui, firstKey)
                    Spacer(Modifier.height(24.dp))
                    HistoryPanel(history, vm)
                }
            }
        }
    }

    (ui as? UiState.Downloading)?.let { ProgressDialog(it, onCancel = vm::cancel) }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Code Downloader", color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("Powered by AFTVnews API / Redirection", color = C.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CodePanel(vm: MainViewModel, code: String, ui: UiState, firstKey: FocusRequester) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().background(C.Card, RoundedCornerShape(16.dp)).padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (code.isEmpty()) "000000" else code,
                color = if (code.isEmpty()) C.Muted.copy(alpha = .4f) else C.Text,
                fontSize = 44.sp, fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold, letterSpacing = 6.sp, textAlign = TextAlign.Center
            )
        }
        Box(Modifier.height(28.dp), contentAlignment = Alignment.Center) {
            when (ui) {
                is UiState.Error -> Text(ui.message, color = C.Error, fontSize = 14.sp)
                UiState.Resolving -> Text("Resolvendo código…", color = C.Muted, fontSize = 14.sp)
                else -> {}
            }
        }
        Keypad(vm, firstKey)
        Spacer(Modifier.height(12.dp))
        FocusButton(
            onClick = { vm.start() }, container = C.Accent,
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("Baixar", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun Keypad(vm: MainViewModel, firstKey: FocusRequester) {
    val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "C"))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEachIndexed { c, k ->
                    FocusButton(
                        onClick = {
                            when (k) { "⌫" -> vm.backspace(); "C" -> vm.clear(); else -> vm.append(k[0]) }
                        },
                        modifier = Modifier.weight(1f).height(58.dp)
                            .then(if (r == 0 && c == 0) Modifier.focusRequester(firstKey) else Modifier)
                    ) { Text(k, color = C.Text, fontSize = 24.sp) }
                }
            }
        }
    }
}

@Composable
private fun HistoryPanel(items: List<HistoryItem>, vm: MainViewModel) {
    Text("Downloads recentes", color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
    if (items.isEmpty()) {
        Text("Nenhum download ainda.", color = C.Muted, fontSize = 14.sp)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { item ->
            Column(Modifier.fillMaxWidth().background(C.Card, RoundedCornerShape(14.dp)).padding(14.dp)) {
                Text(item.fileName, color = C.Text, fontSize = 16.sp, maxLines = 1)
                Text("Código ${item.code}", color = C.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FocusButton({ vm.start(item.code) }, Modifier.weight(1f).height(44.dp)) {
                        Text("Re-baixar", color = C.Text, fontSize = 14.sp)
                    }
                    FocusButton({ vm.delete(item) }, Modifier.weight(1f).height(44.dp)) {
                        Text("Excluir", color = C.Error, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressDialog(s: UiState.Downloading, onCancel: () -> Unit) {
    val cancelFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { cancelFocus.requestFocus() }
    Dialog(onDismissRequest = {}) {
        Column(
            Modifier.fillMaxWidth().background(C.Card, RoundedCornerShape(20.dp)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(s.name, color = C.Text, fontSize = 16.sp, maxLines = 1)
            Spacer(Modifier.height(16.dp))
            if (s.progress != null)
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = C.Accent, trackColor = C.Key)
            else
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(8.dp), color = C.Accent, trackColor = C.Key)
            Spacer(Modifier.height(10.dp))
            Text(
                (s.progress?.let { "${(it * 100).toInt()}%  •  " } ?: "") + "%.1f MB/s".format(s.speed),
                color = C.Muted, fontSize = 14.sp
            )
            Spacer(Modifier.height(18.dp))
            FocusButton(onCancel, Modifier.fillMaxWidth().height(50.dp).focusRequester(cancelFocus)) {
                Text("Cancelar", color = C.Text, fontSize = 16.sp)
            }
        }
    }
}
